from django.shortcuts import get_object_or_404, redirect, render

from .models import QuizQuestion, QuizSong


PASS_PERCENT = 85
SUPPORTED_LANGUAGES = {"en", "ru", "kk"}

LANGUAGE_NAMES = {
    "en": "English",
    "ru": "Русский",
    "kk": "Қазақша",
}


def _language_or_404(language):
    language = language.lower()
    if language not in SUPPORTED_LANGUAGES:
        from django.http import Http404
        raise Http404("Unsupported language")
    return language


def _get_song(language, song_number):
    return get_object_or_404(
        QuizSong,
        language=language,
        number=song_number,
    )


def iliad_page(request, language="en", song_number=1):
    language = _language_or_404(language)
    song = QuizSong.objects.filter(language=language, number=song_number).first()

    if song is None:
        # Keep the default reader URL friendly if a requested song does not
        # exist for this language.
        if song_number != 1:
            from django.http import Http404
            raise Http404("This song is not available for the selected language")

    annotations = song.annotations.all() if song else []
    songs = QuizSong.objects.filter(language=language).order_by("number")
    previous_song = (
        songs.filter(number=song.number - 1).first() if song else None
    )
    next_song = (
        songs.filter(number=song.number + 1).first() if song else None
    )

    # When switching language, stay on the same song if that translation
    # exists; otherwise fall back to Book I.
    language_song_links = {}
    current_number = song.number if song else 1
    for code in SUPPORTED_LANGUAGES:
        target = QuizSong.objects.filter(
            language=code, number=current_number
        ).first()
        if target is None:
            target = QuizSong.objects.filter(language=code, number=1).first()
        language_song_links[code] = target

    return render(
        request,
        "index.html",
        {
            "song": song,
            "songs": songs,
            "annotations": annotations,
            "previous_song": previous_song,
            "next_song": next_song,
            "language_song_links": language_song_links,
            "language": language,
            "language_names": LANGUAGE_NAMES,
            "language_name": LANGUAGE_NAMES[language],
        },
    )


def quiz_home(request, language="en"):
    language = _language_or_404(language)
    songs = QuizSong.objects.filter(language=language)

    return render(
        request,
        "quiz_home.html",
        {
            "songs": songs,
            "language": language,
            "language_names": LANGUAGE_NAMES,
            "pass_percent": PASS_PERCENT,
        },
    )


def _quiz_key(song):
    # Every language is a separate QuizSong, so scores are automatically
    # independent between English, Russian and Kazakh.
    return f"quiz_song_{song.id}"


def _song_result(request, song):
    data = request.session.get(_quiz_key(song), {})
    answered = set(data.get("answered", []))
    correct = int(data.get("correct", 0))
    total = song.questions.count()

    percent = round((correct / total) * 100, 1) if total else 0

    return {
        "answered": answered,
        "correct": correct,
        "total": total,
        "percent": percent,
        "passed": bool(
            total
            and percent > PASS_PERCENT
            and len(answered) >= total
        ),
    }


def _song_is_unlocked(request, song):
    if song.number <= 1:
        return True

    previous_song = QuizSong.objects.filter(
        language=song.language,
        number=song.number - 1,
    ).first()

    if previous_song is None:
        return True

    return _song_result(request, previous_song)["passed"]


def quiz_song(request, language, song_number):
    language = _language_or_404(language)
    song = _get_song(language, song_number)
    songs = QuizSong.objects.filter(language=language)

    if not _song_is_unlocked(request, song):
        return render(
            request,
            "quiz_locked.html",
            {
                "song": song,
                "required_percent": PASS_PERCENT,
                "songs": songs,
                "language": language,
                "language_names": LANGUAGE_NAMES,
            },
        )

    questions = list(song.questions.all())
    result = _song_result(request, song)

    if not questions:
        return render(
            request,
            "quiz_empty.html",
            {
                "song": song,
                "songs": songs,
                "language": language,
                "language_names": LANGUAGE_NAMES,
            },
        )

    try:
        question_number = int(request.GET.get("question", 1))
    except (TypeError, ValueError):
        question_number = 1

    question_number = max(1, min(question_number, len(questions)))
    question = questions[question_number - 1]
    already_answered = question.id in result["answered"]
    selected_option = None
    is_correct = None

    if request.method == "POST" and not already_answered:
        selected_option = request.POST.get("answer")

        if selected_option not in {"a", "b", "c", "d"}:
            return redirect(
                f"{request.path}?question={question_number}"
            )

        is_correct = selected_option == question.correct_option
        data = request.session.get(
            _quiz_key(song),
            {"answered": [], "correct": 0, "answers": {}},
        )
        answered = set(data.get("answered", []))

        if question.id not in answered:
            answered.add(question.id)
            data["answered"] = list(answered)
            data["answers"] = data.get("answers", {})
            data["answers"][str(question.id)] = selected_option

            if is_correct:
                data["correct"] = int(data.get("correct", 0)) + 1

            request.session[_quiz_key(song)] = data
            request.session.modified = True

        result = _song_result(request, song)
        already_answered = True

    elif already_answered:
        data = request.session.get(_quiz_key(song), {})
        selected_answers = data.get("answers", {})
        selected_option = selected_answers.get(str(question.id))
        if selected_option:
            is_correct = selected_option == question.correct_option

    next_question = (
        question_number + 1
        if question_number < len(questions)
        else None
    )

    next_song = QuizSong.objects.filter(
        language=language,
        number=song.number + 1,
    ).first()

    previous_question = question_number - 1 if question_number > 1 else None

    return render(
        request,
        "quiz.html",
        {
            "song": song,
            "songs": songs,
            "questions": questions,
            "question": question,
            "question_number": question_number,
            "already_answered": already_answered,
            "answered_ids": result["answered"],
            "selected_option": selected_option,
            "is_correct": is_correct,
            "next_question": next_question,
            "next_song": next_song,
            "previous_question": previous_question,
            "correct": result["correct"],
            "total": result["total"],
            "percent": result["percent"],
            "passed": result["passed"],
            "pass_percent": PASS_PERCENT,
            "language": language,
            "language_names": LANGUAGE_NAMES,
            "language_name": LANGUAGE_NAMES[language],
        },
    )


def quiz_reset(request, language, song_number):
    language = _language_or_404(language)
    song = _get_song(language, song_number)

    if request.method == "POST":
        request.session.pop(_quiz_key(song), None)
        request.session.modified = True

    return redirect(
        "quiz_song",
        language=language,
        song_number=song.number,
    )
